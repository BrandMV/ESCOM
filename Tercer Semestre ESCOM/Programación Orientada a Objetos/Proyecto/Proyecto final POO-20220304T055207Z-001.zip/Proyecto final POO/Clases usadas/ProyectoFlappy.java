/*
PROYECTO FINAL: “FLAPPY BIRD”
ALUMNO: Meza Vargas Brandon David.
GRUPO: 2CM1
MATERIA: Programación Orientada a Objetos
FECHA: 22-01-21

*/
package proyectoflappy;

import java.awt.Canvas;
import java.awt.*;
import java.awt.Color;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.ServerSocket;
import javax.imageio.ImageIO;
import javax.swing.JTextField;
import java.sql.*;
import java.util.Scanner;
import javax.swing.JButton;
import javax.swing.JFrame;

@SuppressWarnings("serial")
public class ProyectoFlappy extends Canvas implements Runnable{
    
    public static final int LARGO= 868;
    public static final int ANCHO = 430;
    public boolean activo;
    public static boolean muerto, presionado;
    public static boolean ini=false;
    public static Bird bird;
    public static tierra ti;
    public static botones inic, res;
    public static int puntos=0;

    public static String nombre;
    public static BufferedImage fondo, tub, perdio, boton, listo; 
    Thread hilo;
    ServerSocket serverSocket;
    Connection cone;
    Statement st;
    ResultSet rs;
 
    public static void main(String[] args) {
        new frame(ProyectoFlappy.ANCHO, ProyectoFlappy.LARGO, "Proyecto Final - Flappy Bird", new ProyectoFlappy());
    }
    public synchronized void start(){ //una parte de este codigo esta sincronizado
        activo=true;
        hilo = new Thread();
        hilo.start();
        nombre="jugador";
        run();
        
    }
    
    public void tick(){
        if(!muerto && ini){
            controlaObjeto.tick();
            ti.tick();
        } 
    }
    
    public void init(){
            try {
                cone= DriverManager.getConnection("jdbc:mysql://localhost:3306/flappy", "root", "");
               st=cone.createStatement();
               st.executeUpdate("Insert into jugador (usuario, puntos) Values ('"+nombre+"'"+", '"+0+"')");
               
           } catch (Exception a) {
            a.printStackTrace();
           }
        addKeyListener(new teclas());
        addMouseListener(new mouse());
       
                
        try {   
            fondo=ImageIO.read(new File("C:\\Users\\PC\\Documents\\NetBeansProjects\\ProyectoFlappy\\images\\fondo0.png"));
        }catch(IOException e){  System.out.println("Image not found"); }
        try {   
           perdio=ImageIO.read(new File("C:\\Users\\PC\\Documents\\NetBeansProjects\\ProyectoFlappy\\images\\gameo.png"));
        }catch(IOException e){  System.out.println("Image not found"); }
        try {   
           boton=ImageIO.read(new File("C:\\Users\\PC\\Documents\\NetBeansProjects\\ProyectoFlappy\\images\\boton.png"));
        }catch(IOException e){  System.out.println("Image not found"); }
         try {   
           listo=ImageIO.read(new File("C:\\Users\\PC\\Documents\\NetBeansProjects\\ProyectoFlappy\\images\\listo.png"));
        }catch(IOException e){  System.out.println("Image not found"); }
    
        ti = new tierra();
        bird = new Bird(50,50, 51, 36);
        inic=new botones(ProyectoFlappy.ANCHO/2-156/2,320,156,97,boton);
        res=new botones(ProyectoFlappy.ANCHO/2-156/2,320,156,97,boton);
       
        
    }
    
    public void render(){
        BufferStrategy bs= this.getBufferStrategy();
        
        if(bs==null){
            createBufferStrategy(3);
            return;
        }
        
       Graphics g = bs.getDrawGraphics();
       g.drawImage(fondo,0,0,null);

       ti.render(g);
        
       controlaObjeto.render(g);
        g.setFont(new Font("Arial", Font.BOLD, 50));
        g.setColor(Color.WHITE);
        String s=Integer.toString(puntos);
        g.drawString(s,200, 40);
   
       if(muerto){
           g.drawImage(perdio,110,130,null);
           inic.render(g);
           g.setFont(new Font("Arial", Font.BOLD, 20));
           g.setColor(Color.WHITE);
           if(ProyectoFlappy.puntos>Bird.p)
           {
               g.drawString("Tu puntuación mas alta es: "+ProyectoFlappy.puntos,70, 330);
           }else if(Bird.p>ProyectoFlappy.puntos){
               g.drawString("Tu puntuación mas alta es: "+Bird.p,70, 330);
           }
           
          
       }
        if(!ini){
          
           g.drawImage(listo,110,130,null);
           res.render(g);
       }

        g.dispose();
        bs.show();
    }
 
    @Override
    public void run() {
        init();
        this.requestFocus();
        long pasTiem=System.nanoTime();
        double cantTicks= 60.0;
        double ns = 1000000000/cantTicks;
        double delta=0;
        long timer = System.currentTimeMillis();

        while(activo){
            long now = System.nanoTime();
            delta+=(now - pasTiem) / ns;
            pasTiem=now;
            
            while(delta> 0){
                tick();
              
                render();
           
                delta--;
            }
            
            if(System.currentTimeMillis() - timer > 1000){
                timer+=1000;
                aparTubo.tick();
            }
        }
        
        
    }
    
    
    
  
   
}
