/*
PROYECTO FINAL: “FLAPPY BIRD”
ALUMNO: Meza Vargas Brandon David.
GRUPO: 2CM1
MATERIA: Programación Orientada a Objetos
FECHA: 22-01-21

*/
package proyectoflappy;

import java.util.Random;

public class aparTubo {
    private static Random rand=new Random();
    public static int tierraTam=168;
    public static int area=ProyectoFlappy.LARGO - tierraTam;
    public static int espacio=140;
    public static int minTam=40;
    public static int maxTam=area-espacio-minTam;
    public static int delay=1;
    public static int n;
    
    public static void aparecerTubo(){
        int altoUp=rand.nextInt(maxTam)+1;
        while(altoUp <minTam){
            altoUp = rand.nextInt(maxTam)+1;
        }
        
        int altoDown=area-espacio-altoUp;  
        tubo tuboArri=new tubo(500,0,78,altoUp,tipoTubo.ARRIBA);
        tubo tuboAba=new tubo(500,altoUp+espacio,78,altoDown,tipoTubo.ABAJO);
        
        controlaObjeto.añadir(tuboArri);  
        controlaObjeto.añadir(tuboAba); 
    }
    public static void tick(){
        if(n <delay){
            n++;
        }else{
            aparecerTubo();
            n=0;
        }
    }
    
}
