
package proyectoflappy;

public enum tipoTubo { //el tubo solo puede estar abajo o arriba, por eso usamos enum
    ABAJO, ARRIBA;
}
