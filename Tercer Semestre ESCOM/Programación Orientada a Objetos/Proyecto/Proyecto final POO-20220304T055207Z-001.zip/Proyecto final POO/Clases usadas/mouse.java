/*
PROYECTO FINAL: “FLAPPY BIRD”
ALUMNO: Meza Vargas Brandon David.
GRUPO: 2CM1
MATERIA: Programación Orientada a Objetos
FECHA: 22-01-21

*/
package proyectoflappy;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;


public class mouse implements MouseListener{
 
    @Override
    public void mouseClicked(MouseEvent e) {
        
    }

    @Override
    public void mousePressed(MouseEvent e) {
        if(botones.click(e.getX(), e.getY(), ProyectoFlappy.inic)){
            if(ProyectoFlappy.muerto){
                ProyectoFlappy.presionado=true;
                controlaObjeto.list.clear();
                controlaObjeto.añadir(ProyectoFlappy.bird);
                  
                ProyectoFlappy.puntos=0;
                ProyectoFlappy.muerto=false;
                ProyectoFlappy.ini=false;
                ProyectoFlappy.inic.presionado =false;
                    
            }
            
        }
         if(botones.click(e.getX(), e.getY(), ProyectoFlappy.res)){
            if(!ProyectoFlappy.ini){
                ProyectoFlappy.presionado=true;
         
               controlaObjeto.list.clear();
                controlaObjeto.añadir(ProyectoFlappy.bird);
                ProyectoFlappy.ini=true;
                ProyectoFlappy.muerto=false;
                ProyectoFlappy.res.presionado =false;

            }
            
        }
        
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        
    }

    @Override
    public void mouseExited(MouseEvent e) {
        
    }
    
}
