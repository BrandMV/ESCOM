/*
PROYECTO FINAL: “FLAPPY BIRD”
ALUMNO: Meza Vargas Brandon David.
GRUPO: 2CM1
MATERIA: Programación Orientada a Objetos
FECHA: 22-01-21

*/
package proyectoflappy;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import static proyectoflappy.ProyectoFlappy.fondo;


public class tierra {
    
    private BufferedImage tierra;
    private int x1,x2;
    
    private float velX;
    
    public tierra(){
        x1=0;
        x2= ProyectoFlappy.ANCHO;
        velX=3;
         try {   
            tierra=ImageIO.read(new File("C:\\Users\\PC\\Documents\\NetBeansProjects\\ProyectoFlappy\\images\\tie.png"));
        }catch(IOException e){  System.out.println("Image not found"); }

}
    public void tick(){
        x1-=velX;
        x2-=velX;
        
        if(x1+ProyectoFlappy.ANCHO<0)
                x1=ProyectoFlappy.ANCHO;
        if(x2+ProyectoFlappy.ANCHO<0)
                x2=ProyectoFlappy.ANCHO;
    }
    
    public void render(Graphics g){
        g.drawImage(tierra, x1,ProyectoFlappy.LARGO-168,null);
        g.drawImage(tierra,x2,ProyectoFlappy.LARGO-168,null);
    }
    
}
