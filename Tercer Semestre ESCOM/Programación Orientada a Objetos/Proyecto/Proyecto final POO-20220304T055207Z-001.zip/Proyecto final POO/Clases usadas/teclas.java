/*
PROYECTO FINAL: “FLAPPY BIRD”
ALUMNO: Meza Vargas Brandon David.
GRUPO: 2CM1
MATERIA: Programación Orientada a Objetos
FECHA: 22-01-21

*/
package proyectoflappy;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class teclas implements KeyListener{

    @Override
    public void keyTyped(KeyEvent e) {
        
    }

    @Override
    public void keyPressed(KeyEvent e) {
        if(e.getKeyCode()==KeyEvent.VK_SPACE)
            ProyectoFlappy.bird.setVelY(-6);
        
    }

    @Override
    public void keyReleased(KeyEvent e) {
        
    }
    
}
