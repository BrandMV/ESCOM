/*
PROYECTO FINAL: “FLAPPY BIRD”
ALUMNO: Meza Vargas Brandon David.
GRUPO: 2CM1
MATERIA: Programación Orientada a Objetos
FECHA: 22-01-21

*/
package proyectoflappy;

import java.awt.Graphics;
import java.util.LinkedList;

public class controlaObjeto {
    
    public static LinkedList<Objetos> list = new LinkedList<Objetos>();
    public static void añadir(Objetos o){
        list.add(o);
    }
    public static void quitar(Objetos o){
        list.remove(o);
    }
    public static void render(Graphics g){
        Objetos aux=null;
        for(int i=0;i<list.size();i++){
            aux=list.get(i);
            aux.render(g);
        }
    }
    
    public static void tick(){
        Objetos aux= null;
        
        for(int i=0;i<list.size();i++){
            aux=list.get(i);
            aux.tick();
        }
    }
            
    
}
