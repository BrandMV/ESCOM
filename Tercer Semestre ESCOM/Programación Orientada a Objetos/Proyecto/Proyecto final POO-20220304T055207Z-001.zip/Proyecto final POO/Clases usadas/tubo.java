/*
PROYECTO FINAL: “FLAPPY BIRD”
ALUMNO: Meza Vargas Brandon David.
GRUPO: 2CM1
MATERIA: Programación Orientada a Objetos
FECHA: 22-01-21

*/
package proyectoflappy;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class tubo extends Objetos{
    tipoTubo tipo;
    BufferedImage tub;
    
    public tubo(int x, int y, int ancho, int largo, tipoTubo tipo){
        super(x,y,ancho,largo);
        this.tipo=tipo;
        this.velX=3;
        try {   
            tub=ImageIO.read(new File("C:\\Users\\PC\\Documents\\NetBeansProjects\\ProyectoFlappy\\images\\tubo.png"));
        }catch(IOException e){  System.out.println("Image not found"); }

}

    @Override
    public void tick() {
        x-=velX;
        if(x+ancho<0){
            controlaObjeto.quitar(this);
            if(tipo==tipoTubo.ABAJO)
                ProyectoFlappy.puntos+=1;
        }
        
    }

    @Override
    public void render(Graphics g) {
        if(tipo==tipoTubo.ABAJO)
        {
            g.drawImage(tub,x,y,72,alto,null);
        }else if(tipo==tipoTubo.ARRIBA){
            g.drawImage(tub,x,y,72,alto,null);
        }
        
    }
    
}
