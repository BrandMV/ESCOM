/*
PROYECTO FINAL: “FLAPPY BIRD”
ALUMNO: Meza Vargas Brandon David.
GRUPO: 2CM1
MATERIA: Programación Orientada a Objetos
FECHA: 22-01-21

*/
package proyectoflappy;

import java.awt.Button;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

public class botones {
    public int x;
    public int y;
    public int ancho;
    public int alto;
    private BufferedImage bot;
    public boolean presionado;
    
    public botones(int x, int y, int ancho, int alto, BufferedImage bot){
        this.x=x;
        this.y=y;
        this.ancho=ancho;
        this.alto=alto;
        this.bot=bot;
    }
    
    public static boolean click(int mX, int mY, botones btn){
        if( mX>= btn.x && mX<= btn.x+btn.ancho && mY>=btn.y && mY <=btn.y+btn.alto){
            return true; 
        }else{
            return false;
        }
    }
    
    public void render(Graphics g){
        if(presionado){
            g.drawImage(bot,x+1,y+1,ancho-2,alto-2,null);
            
        }else{
            g.drawImage(bot,x,y,null);
        }

    }
    
}
