/*
PROYECTO FINAL: “FLAPPY BIRD”
ALUMNO: Meza Vargas Brandon David.
GRUPO: 2CM1
MATERIA: Programación Orientada a Objetos
FECHA: 22-01-21

*/
package proyectoflappy;

import java.awt.Graphics;
import java.awt.Rectangle;

public abstract class Objetos {
    
    protected int x, y, ancho, alto;
    protected float velX, velY;
    
    public Objetos(int x, int y, int ancho, int alto){
        this.x=x;
        this.y=y;
        this.ancho=ancho;
        this.alto=alto;
    }
    
    public abstract void tick();
    public abstract void render(Graphics g);
    
    public Rectangle getBounds(){
        return new Rectangle(x, y, ancho, alto);
    }
    
    public int getX(){
        return x;
    }
    
    public void setX(int X){
        this.x=x;
    }
    public int getY(){
        return y;
    }
    public void setY(int Y){
        this.y=y;
    }
    public int getAncho(){
        return ancho;
    }
    public void setAncho(int ancho){
        this.ancho=ancho;
    }
    public int getAlto(){
        return alto;
    }
    public void setAlto(int alto){
        this.alto=alto;
    }
    
    public float getVelX(){
        return velX;
    }
    public void setVelX(float velX){
        this.velX=velX;
    }
    
    public float getVelY(){
        return velY;
    }
    public void setVelY(float velY){
        this.velY=velY;
    }
}
