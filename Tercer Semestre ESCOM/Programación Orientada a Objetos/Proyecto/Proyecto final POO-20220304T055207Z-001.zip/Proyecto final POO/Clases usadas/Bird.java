/*
PROYECTO FINAL: “FLAPPY BIRD”
ALUMNO: Meza Vargas Brandon David.
GRUPO: 2CM1
MATERIA: Programación Orientada a Objetos
FECHA: 22-01-21

*/
package proyectoflappy;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.sql.*;
import javax.imageio.ImageIO;
import static proyectoflappy.ProyectoFlappy.puntos;

public class Bird extends Objetos{
    Connection cone;
    Statement st,st2;
    Animacion anima;
    ResultSet rs;
    public float gravedad,maxVel;
    public static int p;
    BufferedImage[] imgs = new BufferedImage[3];

    public Bird(int x, int y, int ancho, int largo) {
        super(x, y, ancho, largo);
        gravedad=0.3f;
        maxVel=12f;
          
        
        
        for(int i=0;i<imgs.length;i++)
         try {   
            imgs[i]=ImageIO.read(new File("C:\\Users\\PC\\Documents\\NetBeansProjects\\ProyectoFlappy\\images\\bird"+(i)+".png"));
        }catch(IOException e){  System.out.println("Image not found"); }
            
        anima = new Animacion(this, 100, true, imgs);
        anima.start();
        controlaObjeto.añadir(this);
    }

    @Override
    public void tick() {
        
        velY+=gravedad;
        y+=velY;
        
        if(velY>maxVel){
            velY=maxVel;
        }
        if(y+alto > ProyectoFlappy.LARGO-166){
            y=ProyectoFlappy.LARGO-166-alto;
            setVelY(0);
        }
        if(y<0){
            y=0;
            setVelY(0);
        }
        
        Objetos temp=null;
        for(int i=0;i<controlaObjeto.list.size();i++){
            temp=controlaObjeto.list.get(i);
            if(temp instanceof tubo){
                if(this.getBounds().intersects(temp.getBounds())){
                    ProyectoFlappy.muerto=true; 
            try {
                cone= DriverManager.getConnection("jdbc:mysql://localhost:3306/flappy", "root", "");
               String query="update jugador set puntos= ? where usuario= ?";
               PreparedStatement pS=cone.prepareStatement(query);
               st = cone.createStatement();
               rs=st.executeQuery("SELECT puntos FROM jugador WHERE usuario='"+ProyectoFlappy.nombre+"'");
               
               if(rs.next()){
                   p=rs.getInt("puntos");
                   if(ProyectoFlappy.puntos>p){
                    pS.setInt(1, ProyectoFlappy.puntos);
                    pS.setString(2,ProyectoFlappy.nombre);
                    pS.executeUpdate();
               }
                   
               }
               
              
           } catch (Exception a) {
            a.printStackTrace();
           }
                }
            }
        }
        anima.tick();
        
    }

    @Override
    public void render(Graphics g) {
        anima.render(g); 
    }
    
    
    
}
