/*
PROYECTO FINAL: “FLAPPY BIRD”
ALUMNO: Meza Vargas Brandon David.
GRUPO: 2CM1
MATERIA: Programación Orientada a Objetos
FECHA: 22-01-21

*/
package proyectoflappy;

import java.io.*;
import java.net.*;
import javax.swing.*;

public class frame  extends JFrame{
    JLabel bien;
    JTextField n;
    public frame(int ancho, int alto, String titulo, ProyectoFlappy flappy){
        try{
            flappy.serverSocket = new ServerSocket(7777);
        }catch(IOException e){
            System.out.println("Ya esta corriendo el juego");
            System.exit(0);
        }
        
        
        
        setTitle(titulo);
        pack(); //hace que la ventana coja el tamaño más pequeño posible que permita ver todos los componentes
        setSize(ancho + getInsets().left + getInsets().right, alto + getInsets().top + getInsets().bottom);

        setLocationRelativeTo(null);
        
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);

        add(flappy);
        flappy.start();
        
    }


         
    
}
