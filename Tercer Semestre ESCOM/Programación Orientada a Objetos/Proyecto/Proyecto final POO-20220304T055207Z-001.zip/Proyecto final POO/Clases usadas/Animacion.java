/*
PROYECTO FINAL: “FLAPPY BIRD”
ALUMNO: Meza Vargas Brandon David.
GRUPO: 2CM1
MATERIA: Programación Orientada a Objetos
FECHA: 22-01-21

*/
package proyectoflappy;

import java.awt.Graphics;
import java.awt.image.BufferedImage;


public class Animacion {
    
    private int x, y, imgAct;
    private long delay, tIni;
    private boolean activo, ciclo;
    private Objetos objetivo;
    private BufferedImage[] imgs;
    
    public Animacion(Objetos objetivo, long delay, boolean ciclo, BufferedImage[] imgs){
        this.x=objetivo.getX();
        this.y=objetivo.getY();
        this.imgAct=0;
        this.delay=delay;
        this.tIni=0;
        this.ciclo=ciclo;
        this.setObjetivo(objetivo);
        this.imgs=imgs;
    }
    
    public Animacion(Objetos objetivo, int x, int y, long delay, boolean ciclo, BufferedImage[] imgs){
        this.x=objetivo.getX() + x;
        this.y=objetivo.getY() + y;
        this.imgAct=0;
        this.delay=delay;
        this.tIni=0;
        this.ciclo=ciclo;
        this.setObjetivo(objetivo);
        this.imgs=imgs;
    }
    
     public Animacion(int x, int y, long delay, boolean ciclo, BufferedImage[] imgs){
        this.x=x;
        this.y=y;
        this.imgAct=0;
        this.delay=delay;
        this.tIni=0;
        this.ciclo=ciclo;
        this.setObjetivo(null);
        this.imgs=imgs;
    }
     
     public void render(Graphics g){
         if (objetivo == null)
             g.drawImage(imgs[imgAct],x, y, null);
         else
             g.drawImage(imgs[imgAct],objetivo.x,objetivo.y, null);
     }
     
     public void tick(){
         long pasTiem = (System.nanoTime() - tIni) / 1000000; //nanoTime devuelve eñ valor actual del temporizador de la maquina
         
         if(pasTiem >= delay && activo){
             imgAct++;
             tIni = System.nanoTime();
         }
         
         if(imgAct == imgs.length){
             imgAct=0;
             if(!activo)
                 stop();
         }
     }
     
     public void start(){
         this.activo=true;
         this.imgAct=0;
         this.tIni=0;
     }
     public void stop(){
         this.activo=false;
         this.imgAct=0;
         this.tIni=0;
     }
     
     public Objetos getObjetivo(){
         return objetivo;
     }
     public void setObjetivo(Objetos objetivo){
         this.objetivo=objetivo;
     }
     public int getX(){
         return x;
     }
     public void setX(int x){
         this.x=x;
     }
     public int getY(){
         return y;
     }
     public void setY(int y){
         this.y=y;
     }
     public int getImgAct(){
         return imgAct;
     }
     public void setImgAct(int imgAct){
         this.imgAct = imgAct;
     }
     
     public long getDelay(){
         return delay;
     }
     public void setDelay(long delay){
         this.delay=delay;
     }
     public boolean isCiclo(){
         return ciclo;
     }
     public void setCiclo(boolean ciclo){
         this.ciclo=ciclo;
     }
     public boolean isActivo(){
         return activo;
     }
     public void setActivo(boolean activo){
         this.activo=activo;
     }
     
     public BufferedImage[] getImgs(){
         return imgs;
     }
     public void setImgs(BufferedImage[] imgs){
         this.imgs = imgs; 
     }
    
    
}
