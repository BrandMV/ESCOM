package Server;

/**
 *
 * @author huert
 */
public class Properties {
    public static final int PORT = 8000, N_THREADS = 4;
}
