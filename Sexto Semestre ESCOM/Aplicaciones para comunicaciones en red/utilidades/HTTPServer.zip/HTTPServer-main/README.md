# HTTPServer
HTTP server using thread pool and connection oriented sockets (methods: GET, POST, HEAD, PUT, DELETE)
