package com.example.cookiess;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;

@WebServlet(name = "helloServlet", value = "/hello-servlet")
public class HelloServlet extends HttpServlet {
    /**
     * Manipula las posibles peticiones enviadas por el cliente:
     * utilizando el atributo method=get • method=post.
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html; charset=UTF-8");
        try(PrintWriter out = response.getWriter()) {
            /*Obtendremos el valor actual de la cookie CuentaCookie
            iterando entre las cookies que se reciban*/
            String nCuenta = null;
            Cookie [] cookies = request.getCookies();
            if(cookies != null) {
                for(int i = 0; i < cookies.length; i++) {
                    if(cookies[i].getName().equals("Cuenta.cookie")) {
                        nCuenta = cookies[i].getValue();
                        break;
                    }
                }
            }
            /** Incrementar el contador para esta página
             * El valor es guardado en la cookie con el nombre "Cuenta.cookie"
             */
            Integer conteo = null;
            if (nCuenta == null) {
                conteo = new Integer(1);
            }else {
                conteo = new Integer(Integer.parseInt(nCuenta) +1);
            }
            Cookie newCookie = new Cookie("Cuenta.cookie", conteo.toString());
            response.addCookie(newCookie);

            String enlacesVisitados = "";
            if (cookies != null) {
                for (int i = 0; i < cookies.length; i++) {
                    if (cookies[i].getName().equals("EnlacesVisitadosCookie")) {
                        enlacesVisitados = cookies[i].getValue();
                        break;
                    }
                }
            }
            String[] enlaces = { "https://www.arquitecturajava.com/que-es-un-servlet/", "https://www.manualweb.net/javaee/introduccion-servlets/", "https://biblus.us.es/bibing/proyectos/abreproy/11416/fichero/MEMORIA_EDITOR_FORMATO_QTI%252FCap%C3%ADtulo+3+Tecnolog%C3%ADa+Java+Servlet.pdf+", "https://dis.um.es/~lopezquesada/documentos/IES_1415/IAW/curso/UT5/ActividadesAlumnos/jsp7/paginas/pag1.html", "https://jorgesuaza76.wixsite.com/facultaddeingenieria/copia-de-procesamiento-de-los-datos-1" };
            enlacesVisitados += "|"; // Separador
            for (String enlace : enlaces) {
                String parametroEnlace = request.getParameter(enlace);
                if (parametroEnlace != null && parametroEnlace.equals("true")) {
                    // Si el enlace ha sido visitado, agregarlo a la cadena
                    enlacesVisitados += enlace + "-";
                }
            }
            Cookie enlacesVisitadosCookie = new Cookie("EnlacesVisitadosCookie", enlacesVisitados);
            response.addCookie(enlacesVisitadosCookie);
            for (String enlace : enlaces) {
                boolean visitado = enlacesVisitados.contains(enlace);
                out.println("<a href='?"+enlace+"=true'>" + enlace + "</a> "
                        + (visitado ? "Meza Vargas Brandon David has visitado esta página" : "No visitado") + "<br>");
            }
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title›Servlet CuentaCookie</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Has visitado esta página " + conteo.toString()
                    + ((conteo.intValue() == 1)?" vez":" veces.")+"</h1>");
            out.println("</body>");
            out.println("</html>") ;
        }
    }
    /**
     * Metodo que se encarga de la petición HTTP POST.
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
}