package com.session.session;

import java.io.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Enumeration;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
@WebServlet(name = "helloServlet", value = "/hello-servlet")
public class HelloServlet extends HttpServlet {
    protected void processRequest (HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html; charset=UTF-8");
        try(PrintWriter out = response.getWriter()) {
            // Obtenemos la sesión actual o creamos una de ser necesario.
            HttpSession sesion = request.getSession(true);
            //Datos de la sesión
            String idSesion = sesion.getId();
            long fechaCreacion = sesion.getCreationTime();
            long fechaUltimoAcceso = sesion.getLastAccessedTime();
            //Incrementa el contador de la sesion del cliente "cuenta. sesion"
            Integer cuenta = (Integer)sesion.getAttribute("cuenta.sesion");
            if (cuenta == null)
                cuenta = 1;
            else
                cuenta = cuenta + 1;

            String timeInSession = getTimeSession(fechaCreacion);
            sesion.setAttribute("cuenta.sesion", cuenta);
            out.println("<!DOCTYPE html>");
            out.println("<html>") ;
            out.println("<head>") ;
            out.println("<title>Servlet SeguimientoSesion</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Has visitado esta página " + cuenta + ((cuenta == 1)?" vez":" veces.")+"</h1>");
            out.println ("<h2>Datos de la sesion actual: </h2>");
            out.println("<h3>Id de la sesión: " + idSesion +"</h3>");
            out.println("<h3>" + (isNewSession(sesion)  ? "Es una sesión nueva" : "Seguimiento a sesión existente") + "</h3>");
            out.println("<h3>Fecha de creación: " + (new Date(fechaCreacion)) +"</h3>");
            out.println("<h3>se accedio por ultima vez:" + (new Date(fechaUltimoAcceso)) +"</h3>");
            out.println("<h3>Ha estado conectado durante " + timeInSession + "</h3>");
            out.println("<h2>Atributos: </h2>");
            Enumeration nombres = sesion.getAttributeNames();
            while (nombres.hasMoreElements()) {
                String param = (String) nombres.nextElement();
                out.println("<h3>"+ param + ": " + sesion. getAttribute (param) + "</h3>");
            }
            out.println("<h3>Meza Vargas Brandon David</h3>");

            out.println("</body>");
            out.println("</html>");
        }
    }

    /*
     * Metodo que se encarga de la petición HTTP GET.
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
    /**
     * Metodo que se encarga de la petición HTTP POST.
     */
    @Override
    protected void doPost (HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest (request, response) ;
    }
    /**
     * Devuelve una descripción breve del servlet.
     */
    @Override
    public String getServletInfo(){
        return "Servlet SeguimientoSesion" ;
    }

    public String getTimeSession(long startTime){
        long currentTime = System.currentTimeMillis();
        long elapsedTime = currentTime - startTime;

        long minutes = (elapsedTime / 1000) / 60;
        long seconds = (elapsedTime / 1000) % 60;

        return minutes + " minutos y " + seconds + " segundos";
    }
    private boolean isNewSession(HttpSession session) {
        // Verifica si la sesión es nueva
        return session.isNew();
    }
}